import React from "react";
import "../style/MainPage.scss";
import ResponsiveDrawer from "./SideBar";

const MainPage = () => {
  return (
    <div>
      <ResponsiveDrawer />
    </div>
  );
};

export default MainPage;
