import React, { useState } from "react";
import {
  TextField,
  Radio,
  RadioGroup,
  FormControl,
  InputBase,
  Box,
  Paper,
  Typography,
} from "@mui/material";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import BottomBody from "./BottomBody";
import SearchIcon from "@mui/icons-material/Search";

const TopBody = () => {
  const [search, setSearch] = useState("");
  const [selectedName, setSelectedName] = useState("");

  return (
    <>
      <Box
        sx={{
          width: "100%", // Full width
          //   minHeight: "100vh", // Full screen height
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          backgroundColor: "#f2f2f2",
          //   p: 2,
        }}
      >
        <Box
          //   elevation={3}
          sx={{
            width: "100%", // Full width
            maxWidth: "100%", // Ensures it stretches across the screen
            p: 3,
            // border: "1px solid #ccc",
            // borderRadius: 2,
            backgroundColor: "#f2f2f2",
            // White background for Paper
          }}
        >
          {/* MUI Search Bar */}
          <Box
            sx={{
              width: "50%",
              mb: 3,
              display: "flex",
              alignItems: "center",
              borderRadius: "4px",
              backgroundColor: "#fff", // Light background
              padding: "5px 10px",
            }}
          >
            <SearchIcon sx={{ color: "gray", mr: 1 }} />
            <InputBase
              placeholder="Search..."
              sx={{
                flex: 1,
                border: "none",
                outline: "none",
                fontSize: "16px",
              }}
            />
          </Box>

          {/* MUI Radio Group with Individual Borders for Each Option */}
          <Box
            sx={{
              width: "100%",
              p: 2,
              border: "1px solid #ccc",
              borderRadius: 1,
              //   backgroundColor: "#", // Light pink background
            }}
          >
            <FormControl sx={{ width: "100%" }}>
              <RadioGroup
                style={{
                  display: "flex",
                  flexDirection: "row",
                  gap: "0.5rem",
                  flexWrap: "wrap",
                }}
                value={selectedName}
                onChange={(e) => setSelectedName(e.target.value)}
              >
                {["John", "Alice", "Bob"].map((name) => (
                  <Box
                    key={name}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      border: "1px solid #ccc",
                      borderRadius: 1,
                      p: 1,
                      mb: 1,
                      width: "40%",
                      gap: "10px",
                      //   backgroundColor: "#e3f2fd", // Light blue background for radio options
                    }}
                  >
                    <Radio value={name} />
                    <UploadFileIcon />
                    <Typography>{name}</Typography>
                  </Box>
                ))}
              </RadioGroup>
            </FormControl>
          </Box>
        </Box>
      </Box>
      <Box
        sx={{
          width: "100%", // Full width
          //   minHeight: "100vh", // Full screen height
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          backgroundColor: "#f2f2f2",
            p: 2,
        }}
      >
        <BottomBody />
      </Box>
    </>
  );
};

export default TopBody;
